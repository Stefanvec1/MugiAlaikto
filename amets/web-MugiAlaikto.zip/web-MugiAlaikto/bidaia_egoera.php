<?php
session_start();
include("konexioa.php");

// Redirigir si no ha iniciado sesión
if (!isset($_SESSION['gidari_id'])) {
    header("Location: gidari.php?alerta=debes_iniciar_sesion");
    exit();
}

$mezua = "";
$ondo = false;
$bidaia_datuak = null;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['bidaia_id'], $_POST['egoera'])) {
    $bidaia_id = intval($_POST['bidaia_id']);
    $egoera = intval($_POST['egoera']);

    if (in_array($egoera, [1, 2])) {
        if ($egoera === 2) {
            $amaieraData = date("Y-m-d");
            $amaieraOrdua = date("H:i:s");

            $stmt = $conn->prepare("UPDATE bidaia SET Egoera = ?, AmaieraData = ?, AmaieraOrdua = ? WHERE BidaiaID = ?");
            $stmt->bind_param("issi", $egoera, $amaieraData, $amaieraOrdua, $bidaia_id);
        } else {
            $stmt = $conn->prepare("UPDATE bidaia SET Egoera = ? WHERE BidaiaID = ?");
            $stmt->bind_param("ii", $egoera, $bidaia_id);
        }

        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $ondo = true;
            if ($egoera == 1) {
                $mezua = "Bidaia onartua eta hasi da!";
                $buelta = "bidaiak_ikusi.php";
            } else {
                $mezua = "Bidaia amaituta!";
                $buelta = "bidaia_historiala.php";
            }
        } else {
            $mezua = "Ez da eguneratu. Saiatu berriro.";
        }

        $stmt->close();

        // Cargar datos del viaje actualizado para mostrar tabla
        $stmt2 = $conn->prepare("SELECT BidaiaID, Abiapuntua, Helmuga, HasieraData, HasieraOrdua, AmaieraData, AmaieraOrdua, PertsonaKop, Egoera FROM bidaia WHERE BidaiaID = ?");
        $stmt2->bind_param("i", $bidaia_id);
        $stmt2->execute();
        $result = $stmt2->get_result();
        if ($result->num_rows > 0) {
            $bidaia_datuak = $result->fetch_assoc();
        }
        $stmt2->close();

    } else {
        $mezua = "Egoera baliogabea.";
    }
} else {
    $mezua = "Datuak falta dira.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="eu">
<head>
    <meta charset="UTF-8" />
    <title>Bidaia Egoera - Gidaria</title>
    <link rel="stylesheet" href="css/estilos.css" />
    <style>
        h1 {
            text-align: center;
            margin-top: 30px;
            color: #333;
        }
        .container {
            max-width: 480px;
            background: #fff;
            margin: 40px auto;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .mezua {
            font-size: 1.3rem;
            margin-bottom: 25px;
            font-weight: 600;
        }
        .success {
            color: #27ae60;
        }
        .error {
            color: #e74c3c;
        }
        table {
            width: 90%;
            margin: 20px auto 40px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            border-radius: 12px;
            overflow: hidden;
        }
        th, td {
            padding: 12px 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #0d0d0d;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .status {
            font-weight: 700;
            font-size: 1.2rem;
            margin-bottom: 40px;
            text-align: center;
            color: white;
            width: 150px;
            margin-left: auto;
            margin-right: auto;
            padding: 10px 0;
            border-radius: 12px;
        }
        .hasita {
            background-color: #3498db;
        }
        .bukatuta {
            background-color: #27ae60;
        }
    </style>
    <?php if ($ondo): ?>
        <meta http-equiv="refresh" content="8;url=<?= htmlspecialchars($buelta) ?>">
    <?php endif; ?>
</head>
<body>

<header class="main-header">
    <div class="logo">
        <img src="imgs/logo_sin_texto_ampliado.png" alt="AlaiktoMUGI logo" />
    </div>
    <nav>
        <a href="index.php" class="button">Menua</a>
        <a href="gidari_panela.php" class="button">Atzera</a>
        <a href="gidari.php" class="button">Gidaria</a>
    </nav>
</header>

<h1>Bidaia Egoera</h1>

<div class="container">
    <div class="mezua <?= $ondo ? 'success' : 'error' ?>">
        <?= htmlspecialchars($mezua) ?>
    </div>

    <?php if ($bidaia_datuak): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Abiapuntua</th>
                    <th>Helmuga</th>
                    <th>Hasiera Data</th>
                    <th>Hasiera Ordua</th>
                    <th>Amaiera Data</th>
                    <th>Amaiera Ordua</th>
                    <th>Pasai Kop</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= $bidaia_datuak['BidaiaID'] ?></td>
                    <td><?= htmlspecialchars($bidaia_datuak['Abiapuntua']) ?></td>
                    <td><?= htmlspecialchars($bidaia_datuak['Helmuga']) ?></td>
                    <td><?= $bidaia_datuak['HasieraData'] ?></td>
                    <td><?= $bidaia_datuak['HasieraOrdua'] ?></td>
                    <td><?= $bidaia_datuak['AmaieraData'] ?? '-' ?></td>
                    <td><?= $bidaia_datuak['AmaieraOrdua'] ?? '-' ?></td>
                    <td><?= $bidaia_datuak['PertsonaKop'] ?></td>
                </tr>
            </tbody>
        </table>

        <div class="status <?= ($bidaia_datuak['Egoera'] == 1) ? 'hasita' : 'bukatuta' ?>">
            <?= ($bidaia_datuak['Egoera'] == 1) ? 'Hasita' : 'Bukatuta' ?>
        </div>
    <?php endif; ?>

    <?php if (!$ondo): ?>
        <a href="gidari_panela.php" class="button">Itzuli</a>
    <?php endif; ?>
</div>
<footer>
    <div style="max-width: 1200px; margin: 0 auto; padding: 30px; background-color: #0d0d0d; color: #ccc; font-size: 0.95em;">
      <div style="display: flex; flex-direction: column; align-items: center; text-align: center; gap: 20px;">
        <div>
          <strong>AlaiktoMUGI S.A.</strong><br>
          Tel: <a href="tel:+34900123456" style="color: #ccc; text-decoration: none;">+34 900 123 456</a><br>
          Email: <a href="mailto:info@alaiktomugi.eus" style="color: #ccc; text-decoration: none;">info@alaiktomugi.eus</a><br>
          Helbidea: Donostia kalea 7, 20001 Bilbo, Euskal Herria
        </div>
        <div>
          <a href="https://facebook.com" target="_blank" style="margin-right: 10px;">
            <img src="imgs/descarga.jpg" alt="Facebook" width="24">
          </a>
          <a href="https://twitter.com" target="_blank" style="margin-right: 10px;">
            <img src="imgs/descarga (1).jpg" alt="Twitter" width="24">
          </a>
          <a href="https://instagram.com" target="_blank" style="margin-right: 10px;">
            <img src="imgs/descarga.png" alt="Instagram" width="24">
          </a>
        </div>
        <div style="text-align: center; margin-top: 20px; font-size: 0.85em; color: #888;">
          &copy; 2025 AlaiktoMUGI S.A. - Eskubide guztiak erreserbatuta.
        </div>
      </div>
    </div>
  </footer>
</body>
</html>

